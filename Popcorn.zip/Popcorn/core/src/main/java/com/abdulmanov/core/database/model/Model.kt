package com.abdulmanov.core.database.model

import com.abdulmanov.core.database.db.entity.Movie
import io.reactivex.Observable


interface Model {
    fun getMovies(offset:Int): Observable<List<Movie>>

    fun insertMovie(movie: Movie)

    fun deleteMovie(movie: Movie)
}