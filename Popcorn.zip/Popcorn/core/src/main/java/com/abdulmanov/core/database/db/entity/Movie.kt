package com.abdulmanov.core.database.db.entity


import android.arch.persistence.room.*
import com.abdulmanov.core.database.db.converter.MovieConverter
import org.jetbrains.annotations.NotNull

@Entity(tableName = "movies")
@TypeConverters(MovieConverter::class)
data class Movie(
    @ColumnInfo(name = "id_movie")
    val idMovie:Long,
    @ColumnInfo(name = "vote_average")
    val voteAverage: Double,
    @ColumnInfo(name = "vote_count")
    val voteCount: Int,
    @ColumnInfo(name = "title")
    val title: String,
    @ColumnInfo(name = "original_title")
    val originalTitle: String,
    @ColumnInfo(name = "poster_path")
    val posterPath: String,
    @ColumnInfo(name = "overview")
    val overview: String,
    @ColumnInfo(name = "release_date")
    val releaseDate: String,
    @ColumnInfo(name = "genre_ids")
    val genreIds: List<String>,
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    val id:Int=0
)