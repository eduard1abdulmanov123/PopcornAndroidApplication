package com.abdulmanov.core.database.db.dao


import android.arch.persistence.room.*
import com.abdulmanov.core.database.db.entity.Movie

@Dao
interface MovieDao {

    @Query("SELECT * FROM movies ORDER BY vote_average DESC LIMIT :limit OFFSET :offset")
    fun getMovies(limit:Int,offset:Int):List<Movie>

    @Insert
    fun insertAll(movies:List<Movie>)

    @Insert
    fun insert(movie:Movie)

    @Update
    fun update(movie:Movie)

    @Delete
    fun delete(movie: Movie)

}