package com.abdulmanov.core.database.db.converter

import android.arch.persistence.room.TypeConverter

class MovieConverter {

    @TypeConverter
    fun fromListString(list:List<String>):String{
        return list.joinToString(",")
    }

    @TypeConverter
    fun toListString(list:String):List<String>{
        return list.split(",")
    }
}