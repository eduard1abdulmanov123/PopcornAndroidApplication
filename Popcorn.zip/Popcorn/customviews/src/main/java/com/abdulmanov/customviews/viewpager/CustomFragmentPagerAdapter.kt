package com.abdulmanov.customviews.viewpager

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.app.FragmentStatePagerAdapter

class CustomFragmentPagerAdapter(fm: FragmentManager): FragmentPagerAdapter(fm) {

    private val fragmentList = mutableListOf<Fragment>()
    private val fragmentTittleList = mutableListOf<String>()

    override fun getItem(p0: Int) = fragmentList[p0]

    override fun getCount() = fragmentList.size

    override fun getPageTitle(position: Int) =fragmentTittleList[position]

    fun addFragment(fragment: Fragment,title:String):CustomFragmentPagerAdapter{
        fragmentList.add(fragment)
        fragmentTittleList.add(title)
        return this
    }
}