package com.abdulmanov.customviews.recyclerview

interface ItemView