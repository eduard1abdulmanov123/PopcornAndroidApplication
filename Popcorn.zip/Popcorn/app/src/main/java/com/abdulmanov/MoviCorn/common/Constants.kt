package com.abdulmanov.MoviCorn.common

interface Constants {

    interface Network{
        companion object{
            const val BASE_PROFILE_PATH_URL_185 = "http://image.tmdb.org/t/p/w185/"
            const val BASE_POSTER_PATH_URL_550 = "http://image.tmdb.org/t/p/w500/"
            const val BASE_POSTER_PATH_URL_185 = "http://image.tmdb.org/t/p/w185/"
            const val YOUTUBE_THUMBNAIL_BASE_URL = "http://img.youtube.com/vi/"
            const val YOUTUBE_THUMBNAIL_IMAGE_QUALITY = "/hqdefault.jpg"
            const val IMDB_BASE_URL = "http://www.imdb.com/title/"
            const val IMDB_PERSON_BASE_URL = "https://www.imdb.com/name/"
        }
    }
}