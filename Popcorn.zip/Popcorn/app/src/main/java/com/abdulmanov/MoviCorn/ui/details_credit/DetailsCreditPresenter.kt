package com.abdulmanov.MoviCorn.ui.details_credit

import com.abdulmanov.MoviCorn.model.mappers.CreditDetailsMapper
import com.abdulmanov.core.network.model.Model
import io.reactivex.disposables.Disposable

class DetailsCreditPresenter(
    private val network:Model
):DetailsCreditContract.Presenter {

    private var view: DetailsCreditContract.View? = null
    private var mapper:CreditDetailsMapper? = null
    private var requestDisposable: Disposable? = null

    override fun attach(view: DetailsCreditContract.View, mapper: CreditDetailsMapper) {
        this.view = view
        this.mapper = mapper
    }

    override fun detach() {
        view = null
        mapper = null
        requestDisposable?.dispose()
    }

    override fun loadData(id: Long, lang: String) {
        view?.showEmptyProgress(true)
        requestDisposable = network.getDetailCredit(id,lang)
            .map(mapper)
            .subscribe(
                {
                    view?.showData(it)
                    view?.showEmptyProgress(false)
                },
                {
                    view?.showEmptyProgress(false)
                    view?.showError(true,it)
                }
            )
    }

    override fun refresh(id: Long, lang: String) {
        view?.showRefreshProgress(true)
        requestDisposable = network.getDetailCredit(id, lang)
            .map(mapper)
            .subscribe(
                {
                    view?.showData(it)
                    view?.showRefreshProgress(false)
                    view?.showError(false)
                },
                {
                    view?.showRefreshProgress(false)
                }
            )
    }
}