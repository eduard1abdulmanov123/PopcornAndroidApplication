package com.abdulmanov.myapplication.ui.common_ui

import com.abdulmanov.core.network.dto.movies.MoviesDTO
import com.abdulmanov.myapplication.model.mappers.FilmShortMapper
import com.abdulmanov.myapplication.model.vo.FilmShort
import io.reactivex.Observable

open class BaseMoviePresenter:BaseMovieContract.Presenter<FilmShort> {

    private var mMoviePaginator: MoviePaginator<FilmShort, MoviesDTO>?=null
    private var mapper: FilmShortMapper = FilmShortMapper()

    override fun attach(view: BaseMovieContract.View<FilmShort>, func: (page: Int) -> Observable<MoviesDTO>) {
        mMoviePaginator =
            MoviePaginator(view, mapper, func)
    }

    override fun detach() {
        mMoviePaginator?.release()
        mMoviePaginator = null
    }

    override fun loadNextPage() {
        mMoviePaginator?.loadNewPage()
    }

    override fun refresh() {
        mMoviePaginator?.refresh()
    }

    override fun loadNewQuery(func:(page:Int)->Observable<MoviesDTO>) {
        mMoviePaginator?.requestFactory = func
        mMoviePaginator?.refresh()
    }
}