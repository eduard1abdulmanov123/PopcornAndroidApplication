package com.abdulmanov.MoviCorn.adapters

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.MoviCorn.common.inflate
import com.abdulmanov.MoviCorn.common.loadImg
import com.abdulmanov.MoviCorn.model.vo.FilmMedium
import kotlinx.android.synthetic.main.item_list_similar_movies.view.*

class SimilarAdapter(private val clickListener: (id:Long)->Unit):RecyclerView.Adapter<SimilarAdapter.SimilarHolder>(){

    private val similarMovies = mutableListOf<FilmMedium>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SimilarHolder {
        return SimilarHolder(parent)
    }

    override fun getItemCount(): Int {
        return similarMovies.size
    }

    override fun onBindViewHolder(holder: SimilarHolder, position: Int) {
       holder.bind(similarMovies[position])
    }

    fun add(data:List<FilmMedium>){
        similarMovies.addAll(data)
        notifyDataSetChanged()
    }

    inner class SimilarHolder(parent: ViewGroup):RecyclerView.ViewHolder(parent.inflate(R.layout.item_list_similar_movies)){
        init {
            itemView.setOnClickListener {
                clickListener.invoke(similarMovies[adapterPosition].id)
            }
        }

        fun bind(filmMedium:FilmMedium){
            with(itemView){
                similar_movie_poster.loadImg(
                    filmMedium.posterPath,
                    R.color.color_background_image,
                    R.drawable.error_image
                )
                similar_movie_name.text = filmMedium.title
                similar_movie_release_data.text = filmMedium.releaseDate.substring(0,4)
                similar_movie_vote_average.text = filmMedium.voteAverage
            }
        }
    }
}