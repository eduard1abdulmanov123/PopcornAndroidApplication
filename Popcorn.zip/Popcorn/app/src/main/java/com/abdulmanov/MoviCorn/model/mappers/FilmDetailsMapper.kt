package com.abdulmanov.MoviCorn.model.mappers

import android.content.Context
import com.abdulmanov.core.network.dto.movies.FilmDetailsDTO
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.BASE_POSTER_PATH_URL_550
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.BASE_PROFILE_PATH_URL_185
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.IMDB_BASE_URL
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.YOUTUBE_THUMBNAIL_BASE_URL
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.YOUTUBE_THUMBNAIL_IMAGE_QUALITY
import com.abdulmanov.MoviCorn.model.vo.Credit
import com.abdulmanov.MoviCorn.model.vo.FilmDetails
import com.abdulmanov.MoviCorn.model.vo.Video
import io.reactivex.functions.Function
import kotlin.Comparator

class FilmDetailsMapper(private val context:Context):Function<FilmDetailsDTO,FilmDetails> {

    override fun apply(filmDetailsDTO: FilmDetailsDTO): FilmDetails {
        return with(filmDetailsDTO) {
            val creditsVO = mutableListOf<Credit>().apply {
                with(credits) {
                    addAll(cast.map {
                        val path =
                            if (it.profilePath != null) BASE_PROFILE_PATH_URL_185 + it.profilePath else it.profilePath
                        Credit(it.id, path, it.name, it.character)
                    })
                    addAll(crew.map {
                        val path =
                            if (it.profilePath != null) BASE_PROFILE_PATH_URL_185 + it.profilePath else it.profilePath
                        Credit(it.id, path, it.name, it.job)
                    })
                }
            }.sortedWith(Comparator sort@{ p0, p1 ->
                if (p1.profilePath == null && p0.profilePath != null)
                    return@sort -1
                else if (p0.profilePath == null && p1.profilePath != null)
                    return@sort 1
                return@sort 0
            })

            val videosVO = videos.results.filter { it.site == "YouTube" }.map {
                Video(it.key, YOUTUBE_THUMBNAIL_BASE_URL + it.key + YOUTUBE_THUMBNAIL_IMAGE_QUALITY)
            }
            val countriesVO = productionCountries.map { it.name }
            val genresVO = genres.map { it.name }
            val similarVO = MoviesDTOtoListFilmMediumMapper().apply(similar)

            FilmDetails(
                id,
                if (posterPath != null) BASE_POSTER_PATH_URL_550 + posterPath else posterPath,
                title,
                originalTitle?: "r",
                releaseDate.split("-")[0],
                voteAverage,
                voteCount,
                countriesVO,
                genresVO,
                if(runtime != null) getRuntime(runtime!!) else null,
                "$${String.format("%,d", budget).replace(',', ' ')}",
                "$${String.format("%,d", revenue).replace(',', ' ')}",
                overview,
                if(imdbId != null)IMDB_BASE_URL + imdbId else null,
                creditsVO,
                videosVO,
                similarVO
            )
        }
    }

    private fun getRuntime(runtime: Int): String {
        val hoursNumber = runtime / 60
        val minutesNumber = runtime % 60
        val hoursString =
            if (hoursNumber == 0)
                ""
            else
                context.resources.getQuantityString(
                    R.plurals.runtime_hours,
                    hoursNumber,
                    hoursNumber
                ) + " "
        val minutesString =
            if (minutesNumber == 0)
                ""
            else
                context.resources.getQuantityString(
                    R.plurals.runtime_minutes,
                    minutesNumber,
                    minutesNumber
                )
        return "$hoursString$minutesString"
    }
}