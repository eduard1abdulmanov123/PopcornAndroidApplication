package com.abdulmanov.MoviCorn.model.vo

data class FilmLittle(
    val id:Long,
    val title:String,
    val voteAverage:Double,
    val releaseDate:String?,
    val posterPath:String?
)