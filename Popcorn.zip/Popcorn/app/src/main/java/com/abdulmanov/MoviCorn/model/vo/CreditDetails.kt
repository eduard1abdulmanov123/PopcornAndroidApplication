package com.abdulmanov.MoviCorn.model.vo

data class CreditDetails(
    val birthday:String?,
    val deathday:String?,
    val id:Long,
    val name:String,
    val gender:String,
    val biography:String,
    val placeOfBirth:String?,
    val profilePath:String?,
    val imdbId:String,
    val movieCredit: MediaCredit
)

data class MediaCredit(
    val cast:List<FilmLittle>,
    val crew:List<FilmLittle>
)