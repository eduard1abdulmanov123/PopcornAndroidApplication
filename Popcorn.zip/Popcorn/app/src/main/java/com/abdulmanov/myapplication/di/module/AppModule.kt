package com.abdulmanov.myapplication.di.module

import android.content.Context
import com.abdulmanov.core.network.model.Model
import com.abdulmanov.core.network.model.NetworkModelImpl
import dagger.Module
import dagger.Provides
import javax.inject.Singleton

@Module
class AppModule(private val context:Context) {

    @Singleton
    @Provides
    fun provideNetworkModel():Model{
        return NetworkModelImpl(context)
    }

}