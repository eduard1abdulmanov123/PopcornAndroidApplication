package com.abdulmanov.MoviCorn.ui.details_movie

import com.abdulmanov.MoviCorn.model.mappers.FilmDetailsMapper
import com.abdulmanov.MoviCorn.model.vo.FilmDetails

interface DetailsMovieContract {

    interface View{
        fun showEmptyProgress(show:Boolean)

        fun showRefreshProgress(show:Boolean)

        fun showError(show:Boolean, error:Throwable?=null)

        fun showMessage(stringId:Int)

        fun showSaved(show:Boolean)

        fun showData(data:FilmDetails)
    }

    interface Presenter{
        fun attach(view:View,mapper: FilmDetailsMapper)

        fun detach()

        fun existFilmInLibrary(id:Long)

        fun clickSavedButton(film:FilmDetails)

        fun loadData(id:Long,lang:String)

        fun refresh(id:Long,lang:String)
    }
}