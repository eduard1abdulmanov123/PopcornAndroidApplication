package com.abdulmanov.myapplication.ui.search

interface SearchContract{

    interface View{
        fun search(key:String?)
    }
}