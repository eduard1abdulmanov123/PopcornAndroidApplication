package com.abdulmanov.myapplication.ui.details

import com.abdulmanov.myapplication.model.mappers.FilmDetailsMapper
import com.abdulmanov.myapplication.model.vo.FilmDetails

interface DetailsContract {

    interface View{

        fun showEmptyProgress(show:Boolean)

        fun showErrorMessage(show:Boolean,error:Throwable)

        fun showData(data:FilmDetails)
    }

    interface Presenter{
        fun attach(view:DetailsContract.View,mapper: FilmDetailsMapper)

        fun detach()

        fun loadData(id:Long,lang:String)
    }
}