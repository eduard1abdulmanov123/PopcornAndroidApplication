package com.abdulmanov.MoviCorn.ui.details_credit

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.IntegerRes
import com.abdulmanov.MoviCorn.BaseApp
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.MoviCorn.di.module.ActivityModule
import com.abdulmanov.MoviCorn.model.mappers.CreditDetailsMapper
import com.abdulmanov.MoviCorn.model.vo.CreditDetails
import kotlinx.android.synthetic.main.activity_details_credit.*
import kotlinx.android.synthetic.main.content_credit_details.*
import kotlinx.android.synthetic.main.content_empty_progress_bar.*
import kotlinx.android.synthetic.main.content_error.*
import kotlinx.android.synthetic.main.item_list_credit.*
import javax.inject.Inject

class DetailsCreditActivity : AppCompatActivity(),DetailsCreditContract.View {

    companion object {
        private const val EXTRA_CREDIT_ID = "CREDIT_ID"
        fun newIntent(context: Context, id: Long): Intent {
            return Intent(context, DetailsCreditActivity::class.java).apply {
                putExtra(EXTRA_CREDIT_ID, id)
            }
        }
    }

    @Inject
    lateinit var presenter:DetailsCreditContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_credit)
        window.setBackgroundDrawable(null)
        initUI()
        BaseApp.instance.appComponent.activityComponent(ActivityModule()).inject(this)
        presenter.attach(this, CreditDetailsMapper(this))
        presenter.loadData(intent.extras?.getLong(EXTRA_CREDIT_ID) as Long,"ru-RU")
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.detach()
    }

    override fun showEmptyProgress(show:Boolean){
        if(show){
            container_credit_details.visibility = View.GONE
            empty_progress_bar.visibility = View.VISIBLE
        } else{
            container_credit_details.visibility = View.VISIBLE
            empty_progress_bar.visibility = View.GONE
        }
    }

    override fun showRefreshProgress(show: Boolean){
        if (show) {
            button_refresh.visibility = View.INVISIBLE
            refresh_progress_bar.visibility = View.VISIBLE
        } else {
            button_refresh.visibility = View.VISIBLE
            refresh_progress_bar.visibility = View.INVISIBLE
        }
    }

    override fun showError(show:Boolean,error:Throwable?){
        Log.d("CreditDetailsView",error.toString())
        error?.stackTrace?.forEach {
            Log.d("CreditDetailsView",it.toString())
        }
        if(show){
            container_credit_details.visibility = View.GONE
            container_error.visibility = View.VISIBLE
        } else{
            container_credit_details.visibility = View.VISIBLE
            container_error.visibility = View.GONE
        }
    }

    override fun showData(data: CreditDetails){
        Log.d("CreditDetailsView",data.id.toString())
        /*Log.d("CreditDetailsView",data.toString())*/
        /*Log.d("CreditDetailsView",data.birthday.toString())
        Log.d("CreditDetailsView",data.deathday.toString())
        Log.d("CreditDetailsView",data.id.toString())
        Log.d("CreditDetailsView",data.name)
        Log.d("CreditDetailsView",data.gender)
        Log.d("CreditDetailsView",data.biography)
        Log.d("CreditDetailsView",data.placeOfBirth.toString())
        Log.d("CreditDetailsView",data.profilePath.toString())*/
        Log.d("CreditDetailsView",data.imdbId)
        /*data.movieCredit.cast.forEach {  Log.d("CreditDetailsView",it.toString()) }
        data.movieCredit.crew.forEach {  Log.d("CreditDetailsView",it.toString()) }*/
        if(data.biography.isEmpty()){
            credit_biography.text = "-"
            biography_read_more.visibility = View.GONE
        }else{
            credit_biography.text = data.biography
        }

        credit_gender.text = data.gender

        if(data.imdbId.isEmpty()){
            credit_network_url.visibility = View.GONE
            credit_network_url_isEmpty.visibility = View.VISIBLE
            credit_network_url_isEmpty.text = "-"
        }else {
            credit_network_url.text = data.imdbId
        }
    }

    private fun initUI(){
        button_refresh.setOnClickListener {
            presenter.refresh(intent.extras?.getLong(EXTRA_CREDIT_ID) as Long,"ru-RU")
        }

        biography_read_more.setOnClickListener {
            if(credit_biography.maxLines == Integer.MAX_VALUE){
                credit_biography.maxLines = 7
                biography_read_more.text = baseContext.getString(R.string.details_credit_read_more)
            }else {
                credit_biography.maxLines = Integer.MAX_VALUE
                biography_read_more.text = baseContext.getString(R.string.details_credit_read_less)
            }
        }

        credit_network_url.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(credit_network_url.text.toString()))
            startActivity(intent)
        }
    }
}
