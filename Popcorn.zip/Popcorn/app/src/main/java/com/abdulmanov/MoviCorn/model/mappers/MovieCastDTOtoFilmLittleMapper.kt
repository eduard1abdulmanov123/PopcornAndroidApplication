package com.abdulmanov.MoviCorn.model.mappers

import com.abdulmanov.MoviCorn.common.Constants
import com.abdulmanov.MoviCorn.model.vo.FilmLittle
import com.abdulmanov.core.network.dto.people.MovieCastDTO
import io.reactivex.functions.Function

class MovieCastDTOtoFilmLittleMapper:Function<MovieCastDTO, FilmLittle> {
    override fun apply(movieCastDTO: MovieCastDTO): FilmLittle{
        return with(movieCastDTO){
            FilmLittle(
                id,
                title,
                voteAverage,
                releaseData,
                posterPath?.let { Constants.Network.BASE_POSTER_PATH_URL_550 + it }
            )
        }
    }
}