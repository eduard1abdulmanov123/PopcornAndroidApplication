package com.abdulmanov.MoviCorn.ui.details_credit

import com.abdulmanov.MoviCorn.model.mappers.CreditDetailsMapper
import com.abdulmanov.MoviCorn.model.vo.CreditDetails

interface DetailsCreditContract {

    interface View{
        fun showEmptyProgress(show:Boolean)

        fun showRefreshProgress(show: Boolean)

        fun showError(show:Boolean,error:Throwable? = null )

        fun showData(data:CreditDetails)
    }

    interface Presenter{
        fun attach(view:View,mapper:CreditDetailsMapper)

        fun detach()

        fun loadData(id:Long,lang:String)

        fun refresh(id:Long,lang:String)
    }
}