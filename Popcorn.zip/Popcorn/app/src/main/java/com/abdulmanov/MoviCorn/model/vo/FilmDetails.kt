package com.abdulmanov.MoviCorn.model.vo

data class FilmDetails(
    val id:Long,
    val posterPath:String?,
    val title:String,
    val originalTitle:String,
    val releaseData:String,
    val voteAverage:Double,
    val voteCount:Long,
    val countries:List<String>,
    val genres:List<String>,
    val runtime:String?,
    val budget:String,
    val revenue:String,
    val overview:String?,
    val urlIMDB:String?,
    val credits:List<Credit>,
    val videos:List<Video>,
    val similar: List<FilmMedium>
)

data class Credit(
    val id:Long,
    val profilePath:String?,
    val name:String,
    val job:String
)

data class Video(
    val pathUrl:String,
    val thumbnail:String
)