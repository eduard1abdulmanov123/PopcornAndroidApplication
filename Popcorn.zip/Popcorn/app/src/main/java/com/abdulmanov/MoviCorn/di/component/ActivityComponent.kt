package com.abdulmanov.MoviCorn.di.component

import com.abdulmanov.MoviCorn.di.module.ActivityModule
import com.abdulmanov.MoviCorn.di.scope.ActivityScope
import com.abdulmanov.MoviCorn.ui.details_credit.DetailsCreditActivity
import com.abdulmanov.MoviCorn.ui.details_movie.DetailsMovieActivity
import dagger.Subcomponent

@ActivityScope
@Subcomponent(modules = [ActivityModule::class])
interface ActivityComponent {
    fun inject(detailsMovieActivity: DetailsMovieActivity)

    fun inject(detailsCreditActivity: DetailsCreditActivity)
}