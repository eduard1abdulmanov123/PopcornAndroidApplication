package com.abdulmanov.MoviCorn.di.module

import com.abdulmanov.core.network.model.Model as NetModel
import com.abdulmanov.core.database.model.Model as DBModel
import com.abdulmanov.MoviCorn.di.scope.ActivityScope
import com.abdulmanov.MoviCorn.ui.details_credit.DetailsCreditContract
import com.abdulmanov.MoviCorn.ui.details_credit.DetailsCreditPresenter
import com.abdulmanov.MoviCorn.ui.details_movie.DetailsMovieContract
import com.abdulmanov.MoviCorn.ui.details_movie.DetailsMoviePresenter
import dagger.Module
import dagger.Provides

@Module
class ActivityModule {

    @ActivityScope
    @Provides
    fun provideDetailsMoviePresenter(network:NetModel, database:DBModel):DetailsMovieContract.Presenter{
        return DetailsMoviePresenter(network,database)
    }

    @ActivityScope
    @Provides
    fun provideDetailsCreditPresenter(network: NetModel): DetailsCreditContract.Presenter{
        return DetailsCreditPresenter(network)
    }
}