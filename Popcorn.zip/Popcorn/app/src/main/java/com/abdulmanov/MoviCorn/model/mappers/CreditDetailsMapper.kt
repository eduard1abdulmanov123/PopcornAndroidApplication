package com.abdulmanov.MoviCorn.model.mappers

import android.content.Context
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.BASE_PROFILE_PATH_URL_185
import com.abdulmanov.MoviCorn.common.Constants.Network.Companion.IMDB_PERSON_BASE_URL
import com.abdulmanov.MoviCorn.model.vo.CreditDetails
import com.abdulmanov.MoviCorn.model.vo.MediaCredit
import com.abdulmanov.core.network.dto.people.CreditDetailsDTO
import io.reactivex.functions.Function

class CreditDetailsMapper(private val context:Context):Function<CreditDetailsDTO,CreditDetails> {

    override fun apply(creditDetailsDTO: CreditDetailsDTO): CreditDetails {
        return with(creditDetailsDTO){
            val dateBirthday = getDate(birthday?.split("-"))
            val dateDeathday = getDate(deathday?.split("-"))
            val movieCastMapper = MovieCastDTOtoFilmLittleMapper()
            val movieCrewMapper = MovieCrewDTOtoFilmLittleMapper()
            val movie = MediaCredit(
                movieCredit.cast.map { movieCastMapper.apply(it)},
                movieCredit.crew.map { movieCrewMapper.apply(it)}
            )
            val biographyCredit =
                if(biography.isEmpty())
                    translations.translations.find { it.name=="English" }?.data?.biography ?: ""
                else
                    biography

            CreditDetails(
                dateBirthday,
                dateDeathday,
                id,
                name,
                getGender(gender),
                biographyCredit,
                placeOfBirth,
                profilePath?.let { BASE_PROFILE_PATH_URL_185 + it},
                IMDB_PERSON_BASE_URL + imdbId,
                movie
            )
        }
    }


    private fun getGender(gender:Int):String{
        return if(gender==2)
            context.getString(R.string.man)
        else
            context.getString(R.string.woman)
    }

    private fun getDate(date:List<String>?):String?{
        return with(date){
            if(this!=null) {
                val number = if(get(2).startsWith("0")) get(2)[1].toString() else get(2)
                "$number ${getMonth(get(1).toInt())} ${get(0)}"
            }
            else
                null
        }
    }

    private fun getMonth(month:Int):String{
        return when(month){
            1 -> context.getString(R.string.january)
            2 -> context.getString(R.string.february)
            3 -> context.getString(R.string.march)
            4 -> context.getString(R.string.april)
            5 -> context.getString(R.string.may)
            6 -> context.getString(R.string.june)
            7 -> context.getString(R.string.july)
            8 -> context.getString(R.string.august)
            9 -> context.getString(R.string.september)
            10 -> context.getString(R.string.october)
            11 -> context.getString(R.string.november)
            12 -> context.getString(R.string.december)
            else -> ""
        }
    }
}