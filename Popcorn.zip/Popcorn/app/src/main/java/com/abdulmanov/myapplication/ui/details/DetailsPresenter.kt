package com.abdulmanov.myapplication.ui.details
import com.abdulmanov.core.network.model.Model
import com.abdulmanov.myapplication.model.mappers.FilmDetailsMapper
import io.reactivex.disposables.Disposable

class DetailsPresenter(private val network:Model): DetailsContract.Presenter {

    private var view:DetailsContract.View? = null
    private var mapper:FilmDetailsMapper?=null
    private var requestDisposable: Disposable? = null

    override fun attach(view: DetailsContract.View,mapper: FilmDetailsMapper) {
        this.view = view
        this.mapper = mapper
    }

    override fun detach() {
        view = null
        mapper = null
        requestDisposable?.dispose()
    }

    override fun loadData(id: Long,lang:String) {
        view?.showEmptyProgress(true)
        requestDisposable = network.getDetailFilm(id.toInt(),lang)
            .map(mapper)
            .subscribe(
            {
                view?.showEmptyProgress(false)
                view?.showData(it)
            },
            {
                view?.showEmptyProgress(false)
                view?.showErrorMessage(true,it)
            }
        )
    }

}