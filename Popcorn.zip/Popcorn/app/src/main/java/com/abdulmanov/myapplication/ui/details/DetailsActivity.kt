package com.abdulmanov.myapplication.ui.details

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import com.abdulmanov.myapplication.BaseApp
import com.abdulmanov.myapplication.R
import com.abdulmanov.myapplication.common.loadImg
import com.abdulmanov.myapplication.di.module.ActivityModule
import com.abdulmanov.myapplication.model.mappers.FilmDetailsMapper
import com.abdulmanov.myapplication.model.vo.FilmDetails
import kotlinx.android.synthetic.main.activity_details.*
import kotlinx.android.synthetic.main.empty_progress_bar.*
import javax.inject.Inject

class DetailsActivity : AppCompatActivity(),DetailsContract.View {

    @Inject
    lateinit var presenter: DetailsContract.Presenter

    companion object {
        private const val EXTRA_ID_FILM = "ID_FILM"
        fun newIntent(context: Context,id:Long): Intent {
            return Intent(context,DetailsActivity::class.java).apply {
                putExtra(EXTRA_ID_FILM,id)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        initCreditsRecyclerView()
        initVideosRecyclerView()
        BaseApp.instance.appComponent.activityComponent(ActivityModule()).inject(this)
        presenter.attach(this, FilmDetailsMapper(baseContext))
    }

    override fun onResume() {
        super.onResume()
        presenter.loadData(intent.extras?.get(EXTRA_ID_FILM) as Long,"ru-RU")
    }

    override fun onDestroy() {
        super.onDestroy()
        presenter.detach()
    }

    override fun showEmptyProgress(show: Boolean) {
        if(show){
            empty_progress_bar.visibility = View.VISIBLE
            container_data.visibility = View.GONE
        }else{
            empty_progress_bar.visibility = View.GONE
            container_data.visibility = View.VISIBLE
        }
    }

    override fun showErrorMessage(show: Boolean, error: Throwable) {
        error.stackTrace.forEach {
            Log.d("FilmDetails",it.toString())
        }
    }

    override fun showData(data:FilmDetails) {
        Log.d("FilmDetails", data.posterPath)
        film_poster.layoutParams.height = (root_view.height*0.8).toInt()
        film_poster.loadImg(data.posterPath)
        film_title.text = data.title
        film_original_title.text=data.originalTitle
        film_released.text = data.releaseData
        film_vote_average.text = data.voteAverage
        film_vote_count.text = data.voteCount
        film_countries.text = data.countries.joinToString(", ")
        film_genres.text = data.genres.joinToString(", ")
        film_runtime.text = data.runtime
        film_budget.text = data.budget
        film_revenue.text = data.revenue
        film_overview.text = data.overview
        (recycler_view_credit.adapter as CreditsAdapter).add(data.credits)
        if(data.videos.isEmpty()){
            container_videos.visibility = View.GONE
        }else {
            (recycler_view_video.adapter as VideosAdapter).add(data.videos)
        }
    }

    private fun initCreditsRecyclerView(){
        val creditsAdapter = CreditsAdapter()
        with(recycler_view_credit){
            layoutManager = LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
            adapter = creditsAdapter
        }
    }

    private fun initVideosRecyclerView(){
        val videosAdapter = VideosAdapter({})
        with(recycler_view_video){
            layoutManager = LinearLayoutManager(context,LinearLayoutManager.HORIZONTAL,false)
            adapter = videosAdapter
        }
    }

}
