package com.abdulmanov.MoviCorn.model.mappers

import com.abdulmanov.MoviCorn.common.Constants
import com.abdulmanov.MoviCorn.model.vo.FilmLittle
import com.abdulmanov.core.network.dto.people.MovieCrewDTO
import io.reactivex.functions.Function

class MovieCrewDTOtoFilmLittleMapper:Function<MovieCrewDTO,FilmLittle> {
    override fun apply(movieCrewDTO: MovieCrewDTO): FilmLittle {
        return with(movieCrewDTO){
            FilmLittle(
                id,
                title,
                voteAverage,
                releaseData,
                posterPath?.let { Constants.Network.BASE_POSTER_PATH_URL_550 + it }
            )
        }
    }
}