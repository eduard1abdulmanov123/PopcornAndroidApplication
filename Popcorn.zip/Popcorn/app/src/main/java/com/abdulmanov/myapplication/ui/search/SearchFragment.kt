package com.abdulmanov.myapplication.ui.search

import android.os.Bundle
import android.support.v4.view.MenuItemCompat
import android.support.v7.widget.SearchView
import android.util.Log
import android.view.*
import com.abdulmanov.core.network.dto.movies.MoviesDTO
import com.abdulmanov.myapplication.R
import com.abdulmanov.myapplication.di.component.FragmentComponent
import com.abdulmanov.myapplication.ui.MainActivity
import com.abdulmanov.myapplication.ui.common_ui.BaseMovieFragment
import io.reactivex.Observable
import kotlinx.android.synthetic.main.empty_data.view.*
import kotlinx.android.synthetic.main.empty_progress_bar.view.*
import kotlinx.android.synthetic.main.error_container.view.*
import kotlinx.android.synthetic.main.fragment_search.*
import kotlinx.android.synthetic.main.fragment_search.view.*


class SearchFragment : BaseMovieFragment(),SearchContract.View {

    companion object {
        const val SEARCH_TAG = "SEARCH_TAG"
        @JvmStatic
        fun newInstance() = SearchFragment()
    }

    private var firstSearch = true

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        (activity as MainActivity).setSupportActionBar(tool_bar)
        setHasOptionsMenu(true)
    }

    override fun onCreateOptionsMenu(menu: Menu?, inflater: MenuInflater?) {
        inflater?.inflate(com.abdulmanov.myapplication.R.menu.menu_search_toolbar, menu)
        val searchMenuItem = menu?.findItem(com.abdulmanov.myapplication.R.id.action_search)
        val searchView = MenuItemCompat.getActionView(searchMenuItem) as SearchView
        searchView.queryHint=context!!.getString(R.string.query_hint)
        searchView.setOnQueryTextListener(object :SearchView.OnQueryTextListener{

            override fun onQueryTextChange(p0: String?): Boolean {
                if(!firstSearch) {
                    search(p0)
                    Log.d("SearchView", "change")
                }else{
                    firstSearch = false
                }
                return false
            }

            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }
        })
    }

    override fun initViewFragment(view: View) {
        buttonRefresh = view.button_refresh
        refreshProgressBar = view.refresh_progress_bar
        emptyProgressBar = view.empty_progress_bar
        containerErrorView = view.container_error
        recyclerView = view.recycler_view_search
        containerEmptyData = view.empty_data
    }

    override fun injectDependency(fragmentComponent: FragmentComponent) {
        fragmentComponent.inject(this)
    }

    override fun getTypeFunctionForFilm(): (page: Int) -> Observable<MoviesDTO> {
        return { page: Int -> networkModel.getPopularMovies(page.toString(), "ru-RU", "RU") }
    }

    override fun getTypeLayoutForFragment() = R.layout.fragment_search

    override fun getTypeLayoutForFilm() = R.layout.item_list_little_poster

    override fun search(key: String?) {
        if(key==null||key.isEmpty()){
            presenter.loadNewQuery { page: Int -> networkModel.getPopularMovies(page.toString(), "ru-RU", "RU") }
        }else{
            presenter.loadNewQuery { page: Int -> networkModel.getSearchMovies(page.toString(), "ru-RU", "RU",key)}
        }
    }
}
