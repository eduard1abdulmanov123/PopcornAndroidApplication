package com.abdulmanov.MoviCorn.ui.details_movie
import com.abdulmanov.core.database.db.entity.Movie
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.core.network.model.Model as NetModel
import com.abdulmanov.core.database.model.Model as DBModel
import com.abdulmanov.MoviCorn.model.mappers.FilmDetailsMapper
import com.abdulmanov.MoviCorn.model.vo.FilmDetails
import io.reactivex.disposables.Disposable


class DetailsMoviePresenter(
    private val network: NetModel,
    private val database:DBModel
): DetailsMovieContract.Presenter {

    private var view: DetailsMovieContract.View? = null
    private var mapper: FilmDetailsMapper? = null
    private var requestDisposable: Disposable? = null

    override fun attach(view: DetailsMovieContract.View, mapper: FilmDetailsMapper) {
        this.view = view
        this.mapper = mapper
    }

    override fun detach() {
        view = null
        mapper = null
        requestDisposable?.dispose()
    }

    override fun existFilmInLibrary(id: Long) {
        requestDisposable = database.existsFilm(id).subscribe(
            {view?.showSaved(true)},
            {},
            { view?.showSaved(false)}
        )
    }

    override fun clickSavedButton(film: FilmDetails) {
        requestDisposable = database.existsFilm(film.id).subscribe(
            {
                database.deleteMovie(film.id).subscribe{
                    view?.showMessage(R.string.details_delete_film)
                    view?.showSaved(false)
                }
            },
            {},
            {
                val movie = Movie(
                    film.id,
                    film.title,
                    film.overview,
                    film.releaseData,
                    film.genres,
                    film.posterPath,
                    film.voteCount,
                    film.voteAverage
                )
                database.insertMovie(movie).subscribe {
                        view?.showMessage(R.string.details_save_film)
                        view?.showSaved(true)
                }
            }
        )
    }

    override fun loadData(id: Long, lang: String) {
        view?.showEmptyProgress(true)
        requestDisposable = network.getDetailFilm(id, lang)
            .map(mapper)
            .subscribe(
                {
                    view?.showData(it)
                    view?.showEmptyProgress(false)
                },
                {
                    view?.showEmptyProgress(false)
                    view?.showError(true, it)
                }
            )
    }

    override fun refresh(id: Long, lang: String) {
        view?.showRefreshProgress(true)
        requestDisposable = network.getDetailFilm(id, lang)
            .map(mapper)
            .subscribe(
                {
                    view?.showData(it)
                    view?.showRefreshProgress(false)
                    view?.showError(false)
                },
                {
                    view?.showRefreshProgress(false)
                }
            )
    }
}