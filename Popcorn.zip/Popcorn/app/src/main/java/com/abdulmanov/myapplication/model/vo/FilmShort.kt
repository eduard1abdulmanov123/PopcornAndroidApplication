package com.abdulmanov.myapplication.model.vo

import com.abdulmanov.customviews.recyclerview.ItemView

data class FilmShort(
    val id: Long,
    val voteAverage: Double,
    val voteCount: Int,
    val title: String,
    val posterPath: String,
    val overview: String,
    val releaseDate: String,
    val genres: List<String>
):ItemView