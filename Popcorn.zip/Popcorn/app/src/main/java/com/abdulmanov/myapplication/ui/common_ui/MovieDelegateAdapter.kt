package com.abdulmanov.myapplication.ui.common_ui

import android.support.v7.widget.RecyclerView
import android.view.View
import android.view.ViewGroup
import com.abdulmanov.customviews.recyclerview.IDelegateAdapter
import com.abdulmanov.customviews.recyclerview.ItemView
import com.abdulmanov.myapplication.common.inflate
import com.abdulmanov.myapplication.common.loadImg
import com.abdulmanov.myapplication.model.vo.FilmShort
import kotlinx.android.synthetic.main.item_list_little_poster.view.*
import com.abdulmanov.myapplication.R
import kotlinx.android.synthetic.main.item_list_big_poster.view.*


class MovieDelegateAdapter(
    private val layout: Int,
    private val clickListener: (id:Long)->Unit
) : IDelegateAdapter<MovieDelegateAdapter.MovieViewHolder, FilmShort> {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return MovieViewHolder(parent)
    }

    override fun onBindViewHolder(holder: MovieViewHolder, item: FilmShort) {
        holder.bind(item)
    }

    override fun isForViewType(item: ItemView) = item is FilmShort


    inner class MovieViewHolder(parent: ViewGroup) : RecyclerView.ViewHolder(parent.inflate(layout)) {
        init {
            //if (layout == R.layout.item_list_big_poster)
                //itemView.layoutParams.height = (parent.height * 0.95).toInt()
        }

        fun bind(item: FilmShort) {
            itemView.setOnClickListener{
                clickListener.invoke(item.id)
            }
            with(itemView) {
                if (layout == R.layout.item_list_big_poster) {
                    big_movie_poster.loadImg(item.posterPath)
                    big_movie_name.text = item.title
                    big_container_for_genres.text = item.genres.joinToString(", ")
                    big_movie_average.text = item.voteAverage.toString()
                    if(item.voteCount==0)
                        big_movie_vote_count.text = context.getString(R.string.vote_count_zero)
                    else
                        big_movie_vote_count.text = context.resources.getQuantityString(R.plurals.vote_count,item.voteCount,item.voteCount)
                } else if (layout == R.layout.item_list_little_poster) {
                    little_movie_poster.loadImg(item.posterPath)
                    little_movie_release.text = item.releaseDate
                    little_movie_name.text = item.title
                    little_movie_vote_average.text = item.voteAverage.toString()
                    little_movie_vote_count.text = String.format("%,d", item.voteCount)
                    little_container_for_genres.text = item.genres.joinToString(", ")
                }
            }
        }
    }
}