package com.abdulmanov.myapplication.common


import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import com.squareup.picasso.Picasso



fun FragmentManager.hideFragment(tag:String){
    val fragment = findFragmentByTag(tag)
    if (fragment != null) {
        beginTransaction().hide(fragment).commitNow()
    }
}

fun FragmentManager.showFragment(tag:String,hostFragment:Int,newFragment: Fragment){
    val fragment = findFragmentByTag(tag)
    val transaction = beginTransaction()
    if(fragment!=null){
        transaction.show(fragment)
    } else {
        transaction.add(hostFragment, newFragment, tag)
    }
    transaction.commitNow()
}

fun ViewGroup.inflate(layoutId:Int, attachToRoot:Boolean = false): View {
    return LayoutInflater.from(context).inflate(layoutId, this, attachToRoot)
}

fun ImageView.loadImg(imageUrl:String) {
    if(!imageUrl.isEmpty()) {
        Picasso.get()
            .load(imageUrl)
            .fit()
            .centerCrop(ImageView.TEXT_ALIGNMENT_CENTER)
            .into(this)
    }
}

