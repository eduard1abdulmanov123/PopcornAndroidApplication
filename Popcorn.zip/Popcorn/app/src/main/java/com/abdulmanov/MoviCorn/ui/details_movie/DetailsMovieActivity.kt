package com.abdulmanov.MoviCorn.ui.details_movie

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewTreeObserver
import androidx.appcompat.content.res.AppCompatResources
import androidx.core.view.ViewCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.abdulmanov.MoviCorn.BaseApp
import com.abdulmanov.MoviCorn.di.module.ActivityModule
import com.abdulmanov.MoviCorn.model.mappers.FilmDetailsMapper
import com.abdulmanov.MoviCorn.model.vo.FilmDetails
import com.google.android.material.snackbar.Snackbar
import kotlinx.android.synthetic.main.activity_details_movie.*
import kotlinx.android.synthetic.main.content_empty_progress_bar.*
import kotlinx.android.synthetic.main.content_error.*
import javax.inject.Inject
import com.abdulmanov.MoviCorn.R
import com.abdulmanov.MoviCorn.common.loadImg
import com.abdulmanov.MoviCorn.ui.details_credit.DetailsCreditActivity
import com.abdulmanov.MoviCorn.adapters.CreditsAdapter
import com.abdulmanov.MoviCorn.adapters.SimilarAdapter
import com.abdulmanov.MoviCorn.adapters.VideosAdapter
import com.abdulmanov.MoviCorn.ui.video.VideoActivity
import kotlinx.android.synthetic.main.content_movie_details.*


class DetailsMovieActivity : AppCompatActivity(),DetailsMovieContract.View {

    companion object {
        private const val EXTRA_FILM_ID = "FILM_ID"
        fun newIntent(context: Context, id: Long): Intent {
            return Intent(context, DetailsMovieActivity::class.java).apply {
                putExtra(EXTRA_FILM_ID, id)
            }
        }
    }

    @Inject
    lateinit var mPresenter: DetailsMovieContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_movie)
        window.setBackgroundDrawable(null)
        initUI()
        BaseApp.instance.appComponent.activityComponent(ActivityModule()).inject(this)
        mPresenter.attach(this, FilmDetailsMapper(this))
        mPresenter.loadData(intent.extras?.get(EXTRA_FILM_ID) as Long, "ru-RU")
    }

    override fun onDestroy() {
        super.onDestroy()
        mPresenter.detach()
    }

    override fun showEmptyProgress(show: Boolean) {
        if (show) {
            empty_progress_bar.visibility = View.VISIBLE
            container_data.visibility = View.GONE
            save_button.visibility = View.GONE
            send_button.visibility = View.GONE
        } else {
            empty_progress_bar.visibility = View.GONE
            container_data.visibility = View.VISIBLE
            save_button.visibility = View.VISIBLE
            send_button.visibility = View.VISIBLE
        }
    }

    override fun showRefreshProgress(show: Boolean) {
        if (show) {
            button_refresh.visibility = View.INVISIBLE
            refresh_progress_bar.visibility = View.VISIBLE
        } else {
            button_refresh.visibility = View.VISIBLE
            refresh_progress_bar.visibility = View.INVISIBLE
        }
    }

    override fun showError(show: Boolean, error: Throwable?) {
        if (show) {
            container_error.visibility = View.VISIBLE
            container_data.visibility = View.GONE
            save_button.visibility = View.GONE
            send_button.visibility = View.GONE
        } else {
            container_error.visibility = View.GONE
            container_data.visibility = View.VISIBLE
            save_button.visibility = View.VISIBLE
            send_button.visibility = View.VISIBLE
        }
    }

    override fun showMessage(stringId: Int) {
        val str = baseContext.resources.getString(stringId)
        Snackbar.make(root_view, str, Snackbar.LENGTH_SHORT).show()
    }

    override fun showSaved(show: Boolean) {
        val res = if (show) R.drawable.ic_saved else R.drawable.ic_save
        save_button.setImageDrawable(AppCompatResources.getDrawable(baseContext, res))
    }

    override fun showData(data: FilmDetails) {
        mPresenter.existFilmInLibrary(intent.extras?.get(EXTRA_FILM_ID) as Long)
        save_button.setOnClickListener {
            mPresenter.clickSavedButton(data)
        }
        send_button.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_TEXT,data.urlIMDB)
            startActivity(intent)
        }

        if(!data.posterPath.isNullOrEmpty())
            film_poster.loadImg(data.posterPath,R.drawable.rectangle_gray_transparent)
        film_title.text = data.title
        film_original_title.text = data.originalTitle
        film_released.text = data.releaseData
        film_vote_average.text = data.voteAverage.toString()
        film_vote_count.text =
            if (data.voteCount == 0.toLong())
                baseContext.getString(R.string.vote_count_zero)
            else
                baseContext.resources.getQuantityString(
                    R.plurals.vote_count,
                    data.voteCount.toInt(),
                    data.voteCount.toInt()
                )

        if (!data.countries.isNullOrEmpty()) {
            container_country.visibility = View.VISIBLE
            film_countries.text = data.countries.joinToString(", ")
        }

        if (!data.genres.isNullOrEmpty()) {
            container_genre.visibility = View.VISIBLE
            film_genres.text = data.genres.joinToString(", ")
        }

        if (!data.runtime.isNullOrEmpty()) {
            container_time.visibility = View.VISIBLE
            film_runtime.text = data.runtime
        }

        film_budget.text = data.budget
        film_revenue.text = data.revenue

        if (!data.overview.isNullOrEmpty()) {
            container_overview.visibility = View.VISIBLE
            film_overview.text = data.overview
        }

        if (!data.credits.isNullOrEmpty()) {
            container_credits.visibility = View.VISIBLE
            (recycler_view_credit.adapter as CreditsAdapter).add(data.credits)
        }

        if (!data.videos.isNullOrEmpty()) {
            container_videos.visibility = View.VISIBLE
            (recycler_view_video.adapter as VideosAdapter).add(data.videos)
        }

        if(!data.similar.isNullOrEmpty()){
            container_similar.visibility = View.VISIBLE
            (recycler_view_similar.adapter as SimilarAdapter).add(data.similar)
        }
    }

    private fun initUI() {
        initRecyclerView(
            CreditsAdapter{
                startActivity(DetailsCreditActivity.newIntent(baseContext,it))
            },
            recycler_view_credit

        )
        initRecyclerView(
            VideosAdapter {
                startActivity(VideoActivity.newIntent(baseContext, it))
            },
            recycler_view_video
        )

        initRecyclerView(
            SimilarAdapter{
                startActivity(DetailsMovieActivity.newIntent(baseContext,it))
            },
            recycler_view_similar
        )

        root_view.viewTreeObserver.addOnPreDrawListener(object :
            ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                root_view.viewTreeObserver.removeOnPreDrawListener(this)
                film_poster.layoutParams.height = (root_view.height * 0.8).toInt()
                return true
            }
        })

        back_button.setOnClickListener {
            finish()
        }

        button_refresh.setOnClickListener {
            mPresenter.refresh((intent.extras?.get(EXTRA_FILM_ID) as Long), "ru-RU")
        }
    }

    private fun initRecyclerView(
        customAdapter: RecyclerView.Adapter<*>,
        recyclerView: RecyclerView
    ) {
        ViewCompat.setNestedScrollingEnabled(recyclerView,false)
        with(recyclerView) {
            layoutManager = LinearLayoutManager(
                context,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            adapter = customAdapter
        }
    }
}
